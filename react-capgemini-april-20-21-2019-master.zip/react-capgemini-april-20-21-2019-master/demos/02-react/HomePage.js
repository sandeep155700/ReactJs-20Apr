<PrimaryMenu links={[ "Pull requests", "Issues" ]}></PrimaryMenu>
<div>
    <StyledButtons buttonText={Unwatch} buttonLabel={2} buttonType="eye" />
    <StyledButtons buttonText={Star} buttonLabel={0} buttonType="star" />
    <StyledButtons buttonText={Fork} buttonLabel={1} buttonType="fork" />
</div>