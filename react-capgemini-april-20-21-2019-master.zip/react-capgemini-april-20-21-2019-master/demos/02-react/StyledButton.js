<span>
    <span><img src={buttonType} /></span>
    <span>{buttonText}</span>
    <span>{buttonLabel}</span>
</span>