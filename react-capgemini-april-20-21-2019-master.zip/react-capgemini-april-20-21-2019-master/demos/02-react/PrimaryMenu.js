<div>
    <span><img src="octocat.jpg" /></span>
    <input type="search" />
</div>