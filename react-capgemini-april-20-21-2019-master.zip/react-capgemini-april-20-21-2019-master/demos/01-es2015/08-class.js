class Person {
    constructor( name, age, city ) { // "this" will be the newly created object
        this.name = name;
        this.age = age;
        this.city = city;
    }

    celebrateBirthday() { // "this" refers to the object
        this.age++;
    }

    // add getter and setter methods for city property
    getCity() {
        return this.city;
    }

    setCity( city ) {
        this.city = city;
    }
}

const john = new Person( 'John', 32, 'Bangalore' ); // empty object
console.log( john );

john.celebrateBirthday();
console.log( john );

console.log( john.getCity() );

john.setCity( 'Chennai' );
console.log( john.getCity() );