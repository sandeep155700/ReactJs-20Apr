function foo( x, y ) {
    console.log( x, y );
    console.log( 'foo context = ', this );

    function bar() {
        console.log( 'bar context = ', this );
    }

    bar();
    
    const baz = () => {
        console.log( 'baz context = ', this );
    }

    baz();
}

foo(); // window, window, window
foo.call( "hello" ); // "hello", window, "hello"

const boundFoo = foo.bind( "hello" );
boundFoo(); // context will be "hello"

const boundFoo2 = foo.bind( "world", 10 );
boundFoo2( 30 );
boundFoo2( 40 );