class Person {
    constructor( name, age, city ) { // "this" will be the newly created object
        this.name = name;
        this.age = age;
        this.city = city;
    }

    celebrateBirthday() { // "this" refers to the object
        this.age++;
    }

    // add getter and setter methods for city property
    getCity() {
        return this.city;
    }

    setCity( city ) {
        this.city = city;
    }
}

class Employee extends Person {
    constructor( name, age, city, role, dept ) {
        super( name, age, city );

        this.role = role;
        this.dept = dept;
    }

    // promote() : should make "Web Developer" a "Senior Web Developer"
    promote() {
        this.role = `Senior ${this.role}`;
    }

    celebrateBirthday() { // override base class (Person class) method
        super.celebrateBirthday(); // call base class method
        console.log( 'Happy Birthday from all of us' ); // do something else apart from that
    }
}

const john = new Employee( 'John', 32, 'Bangalore', 'Web Developer', 'IT' );
console.log( john );
john.celebrateBirthday(); // inherited method will be called via super.celebrateBithday() + logs birthday message
console.log( john ); // age must have increased
john.promote(); // john's role is now "Senior Web Developer"
console.log( john );