# Simple web Server installation
npm i -g http-server