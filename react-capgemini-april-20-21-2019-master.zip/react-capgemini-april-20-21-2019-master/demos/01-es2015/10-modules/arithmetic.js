// public (other modules can use sum)
export const sum = ( x, y ) => x + y;

// private to this module
const subtract = ( x, y ) => x - y;

// only one can be a default export
const x = 100;
export default x; 