const john = {
    name: 'John',
    age: 32,
    address: {
        first_line: '32 Rosewell Court',
        second_line: 'Rockwell',
        city: 'New York'
    },
    emailids: [
        'john@example.com',
        'john@gmail.com'
    ]
};

// const name = john.name, first_line = john.address.first_line, primaryEmailId = john.emailids[0];
const { name = 'Jonathan', ssn = '12345678', address: { first_line : firstLine }, emailids : [ primaryEmailId ] } = john;
console.log( name, ssn, firstLine, primaryEmailId );

