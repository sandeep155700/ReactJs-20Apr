
// Old Syntax 1: Function declaration
function sum1( x, y ) {
    return x + y;
}

// Old Syntax 2: Function expression
const sum2 = function( x, y ) {
    return x + y;
};

console.log( sum1( 10, 20 ) );
console.log( sum2( 10, 20 ) );

// New syntax: Arrow function syntax (ES2015 syntax)
const sum3 = ( x, y ) => {
    return x + y;
};
console.log( sum3( 10, 20 ) );

const sum4 = ( x, y ) => x + y;
console.log( sum4( 10, 20 ) );

const square = x => x * x;
console.log( square( 20 ) );