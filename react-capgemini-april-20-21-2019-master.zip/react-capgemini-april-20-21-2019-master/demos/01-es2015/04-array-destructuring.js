const days = [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday'
];

// const first = days[0], second = days[1], fifth = days[4];
const [ first, second = 'Holiday', , , fifth, sixth = 'Holiday' ] = days;
console.log( first, second, fifth, sixth );