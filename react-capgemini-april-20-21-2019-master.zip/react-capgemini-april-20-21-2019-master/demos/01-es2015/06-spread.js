// ... (spread)

// on arrays - it substitutes with comma-separated items
const arr1 = [ 1, 2, 3 ], arr2 = [ 4, 5, 6 ];
const arr3 = [ ...arr1, ...arr2 ];
console.log( arr3 );

const john = {
    name: 'John',
    age: 32,
    address: {
        first_line: '32 Rosewell Court',
        second_line: 'Rockwell',
        city: 'New York'
    },
    emailids: [
        'john@example.com',
        'john@gmail.com'
    ]
};

const johnCopy = { ...john }; // comma-separated key-value pairs are substituted in place of ...john
console.log( johnCopy );

johnCopy.address.city = 'Chicago';

console.log( john );
console.log( johnCopy );

const johnCopy2 = {
    ...john,
    address: { ...john.address }, // override address and assign to a new object with address properties copied over
    emailids: [ ...john.emailids ]
};
johnCopy2.city = 'New Jersey';
console.log( john );
console.log( johnCopy2 );