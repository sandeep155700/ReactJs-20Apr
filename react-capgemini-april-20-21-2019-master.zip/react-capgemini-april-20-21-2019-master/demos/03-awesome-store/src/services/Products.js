import axios from 'axios';

const Products = {
    getAll() {
        return axios.get( 'https://awesome-store-server.herokuapp.com/products' )
            .then(response => {
                // the axios response object has a data property which holds data received from backend
                return response.data;
            })
            .catch(error => {
                console.log( error.message );
                
                // throw the error so that the component calling this can handle the error in a way it wants
                throw error;
            });
    },
    get( id ) {
        return axios.get( 'https://awesome-store-server.herokuapp.com/products/' + id )
            .then(response => {
                return response.data;
            })
            .catch(error => {
                console.log( error.message );
                
                throw error;
            });
    }
};

export default Products;