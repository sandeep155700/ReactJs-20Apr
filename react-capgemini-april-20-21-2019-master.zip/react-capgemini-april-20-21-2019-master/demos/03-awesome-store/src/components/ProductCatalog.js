import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import ProductService from '../services/Products';

const INITIALIZING = 'INITIALIZING';
const FETCHING_PRODUCTS = 'FETCHING_PRODUCTS';
const FETCHED_PRODUCTS = 'FETCHED_PRODUCTS';
const FETCHING_PRODUCTS_ERRORED = 'FETCHING_PRODUCTS_ERRORED';

class ProductCatalog extends Component {
    state = {
        products: [],
        status: INITIALIZING    
    };

    render() {
        const { products, status } = this.state;

        switch( status ) {
            case INITIALIZING:
                return (
                    <div className="container">
                        <div className="alert alert-info">
                            Page is loading
                        </div>
                    </div>
                );
            case FETCHING_PRODUCTS:
                return (
                    <div className="container">
                        <div className="alert alert-info">
                            Products are being fetched
                        </div>
                    </div>
                );
            case FETCHED_PRODUCTS:
                return (
                    <table className="table table-light table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                products.map(product => (
                                    <tr key={product.id}>
                                        <td>
                                            <Link to={"/catalog/" + product.id}>{product.name}</Link>
                                        </td>
                                        <td>{product.description}</td>
                                        <td>{product.price}</td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                )
            case FETCHING_PRODUCTS_ERRORED:
                return (
                    <div className="alert alert-danger">
                        Unable to fetch products
                    </div>
                );
        }
    }

    componentDidMount() {
        this.setState({
            status: FETCHING_PRODUCTS
        });
        
        ProductService.getAll() // redux-thunk can be used when you use redux
            .then(products => {
                this.setState({
                    products: products,
                    status: FETCHED_PRODUCTS
                });
            })
            .catch(error => {
                this.setState({
                    products: [],
                    status: FETCHING_PRODUCTS_ERRORED,
                    error: error
                })
            });
    }
}

export default ProductCatalog;