import React from 'react';
import { Route, Link } from 'react-router-dom';

import About from './About';
import ProductCatalog from './ProductCatalog';
import ProductDetail from './ProductDetail';

const App = () => {
    return (
        <React.Fragment>
            <nav className="navbar navbar-expand navbar-light bg-light">
                <ul className="nav navbar-nav">
                    <li className="nav-item active">
                        <Link className="nav-link" to="/">Awesome Store</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="nav-link" to="/catalog">Product Catalog</Link>
                    </li>
                </ul>
            </nav>
            <div className="container mt-3">
                <Route path="/" exact={true} component={About} />
                <Route path="/catalog" exact={true} component={ProductCatalog} />
                <Route path="/catalog/:id" exact={true} component={ProductDetail} />
            </div>
        </React.Fragment>
    );
};

export default App;