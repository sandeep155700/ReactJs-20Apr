import React, { Component } from 'react';
import ProductService from '../services/Products';

const INITIALIZING = 'INITIALIZING';
const FETCHING_PRODUCT = 'FETCHING_PRODUCT';
const FETCHED_PRODUCT = 'FETCHED_PRODUCT';
const FETCHING_PRODUCT_ERRORED = 'FETCHING_PRODUCT_ERRORED';

class ProductDetail extends Component {
    state = {
        product: {},
        status: INITIALIZING    
    };

    render() {
        const { product, status } = this.state;

        switch( status ) {
            case INITIALIZING:
                return (
                    <div className="container">
                        <div className="alert alert-info">
                            Page is loading
                        </div>
                    </div>
                );
            case FETCHING_PRODUCT:
                return (
                    <div className="container">
                        <div className="alert alert-info">
                            Product details are being fetched
                        </div>
                    </div>
                );
            case FETCHED_PRODUCT:
                return (
                    <div class="row">
                        <div class="col">
                            <img src={product.imageUrl} class="img-fluid" />
                        </div>
                        <div class="col">
                            <h2>{product.name}</h2>
                            <p>{product.description}</p>
                            <p><strong>Code</strong>: {product.code}</p>
                            <p><strong>Price</strong>: ${product.price}</p>
                            <p><strong>Rating</strong>: {product.starRating} / 5</p>
                        </div>
                    </div>
                )
            case FETCHING_PRODUCT_ERRORED:
                return (
                    <div className="alert alert-danger">
                        Unable to fetch product details
                    </div>
                );
        }
    }

    componentDidMount() {
        this.setState({
            status: FETCHING_PRODUCT
        });
        
        ProductService.get( this.props.match.params.id )
            .then(product => {
                this.setState({
                    product: product,
                    status: FETCHED_PRODUCT
                });
            })
            .catch(error => {
                this.setState({
                    product: {},
                    status: FETCHING_PRODUCT_ERRORED,
                    error: error
                })
            });
    }
}

export default ProductDetail;