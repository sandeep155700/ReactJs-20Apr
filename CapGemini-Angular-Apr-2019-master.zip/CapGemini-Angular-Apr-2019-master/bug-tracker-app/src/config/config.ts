let configuration = {
	bugServiceEndPoint : 'http://localhost:3000/bugs'
}

export default configuration;

